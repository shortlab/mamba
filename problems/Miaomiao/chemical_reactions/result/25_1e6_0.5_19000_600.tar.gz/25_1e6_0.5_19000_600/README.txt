Goal: get Tavg of vapor using energy balance for different coolant temperature.

The time steps in crud_chem_5th.i is 10, which is enough to arrive at steady state now.

File Name: {crud thickness}_{heat flux from cladding}_{porosity}_{h_convection_coolant}_{T_coolant}, 25 microns, 1MW/m^2, 0.5,19000W/m^2, 600 K, respectively.


