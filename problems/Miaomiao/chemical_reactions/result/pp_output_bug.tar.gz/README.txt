
ATTENTION:
The result is very different from what I got after I update moose and change the sign (from '+' to '-') in ChimneyEvaporationBC.C. ( Now it seems that '-' is correct). This means the result in this tar file could probably wrong.

This tar file is: 
T_coolant: 584 K
heat flux: 1.0e5 to 1.5e6 W/m^2
thickness: 25 microns
h: 12000 W/m^2
sub_5th_0_{heat flux}.txt: output of master file: crud_chem_5th.i
sub_5th_number_{heat flux}.txt: output of sub file: sub_5th.i
subsub_5th_{heat flux}: output of subsub file: subsub_5th.i


