
ATTENTION:
The result is what I got after I update moose and change the sign (from '+' to '-') in ChimneyEvaporationBC.C. ( Now it seems that '-' is correct). Very different from tar file pp_output_bug.tar.gz. The comparison can be seen from vaporheight.txt whose upper part is older one from pp_output_bug.tar.gz and lower part is current result

This tar file is: 

convection coefficient: 12000 W/m^2
T_coolant: 584 K
heat flux: 1.0e5 to 1.2e6 W/m^2
thickness: 25 microns
sub_5th_0_{heat flux}.txt: output of master file: crud_chem_5th.i (num_steps = 7, dt=1.0e-2)
sub_5th_number_{heat flux}.txt: output of sub file: sub_5th.i(num_steps = 5, dt=1.0e-3)
subsub_5th_{heat flux}: output of subsub file: subsub_5th.i (num_steps = 4, dt=1.0e-3)



